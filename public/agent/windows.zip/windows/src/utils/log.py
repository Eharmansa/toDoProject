import logging
from pathlib import Path
from datetime import datetime
import sys

def setup_logger():
    """Logger yapılandırması"""
    try:
        # Log dizini
        if getattr(sys, 'frozen', False):
            exe_dir = Path(sys.executable).parent
        else:
            exe_dir = Path.cwd()
            
        log_dir = exe_dir / "logs"
        log_dir.mkdir(exist_ok=True)
        
        # Log dosya adı
        tarih = datetime.now().strftime("%Y-%m-%d")
        log_dosyasi = log_dir / f"Sistem_Bilgi_{tarih}.log"
        
        # Log formatı
        format = logging.Formatter(
            '[%(asctime)s] %(levelname)s - %(name)s - %(message)s',
            '%Y-%m-%d %H:%M:%S'
        )
        
        # Dosya handler
        dosya_handler = logging.FileHandler(log_dosyasi, encoding='utf-8')
        dosya_handler.setFormatter(format)
        dosya_handler.setLevel(logging.INFO)
        
        # Konsol handler
        konsol_handler = logging.StreamHandler()
        konsol_handler.setFormatter(format)
        konsol_handler.setLevel(logging.INFO)
        
        # Ana logger
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        
        # Önceki handlerlari temizle
        logger.handlers.clear()
        
        # Yeni handlerları ekle
        logger.addHandler(dosya_handler)
        logger.addHandler(konsol_handler)
        
        return logger
        
    except Exception as e:
        print(f"Log sistemi başlatılamadı: {e}")
        raise 