import logging
from datetime import datetime
from pathlib import Path
import sys
import json
import socket

from collectors.hw import HWCollector as DonanımToplayici
from collectors.sw import SWCollector as YazılımToplayici
from collectors.net import NetCollector as AğToplayici
from collectors.sec import SecCollector as GüvenlikToplayici

class Agent:
    def __init__(self):
        self.log = logging.getLogger(__name__)
        
        # Çıktı dizini
        exe_dir = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path.cwd()
        self.out_dir = exe_dir / "output"
        self.out_dir.mkdir(exist_ok=True)
        
        # Toplayıcılar
        self.collectors = {
            'donanim': DonanımToplayici(),
            'yazilim': YazılımToplayici(),
            'ag': AğToplayici(),
            'guvenlik': GüvenlikToplayici()
        }

    def collect(self):
        """Sistem bilgilerini topla ve kaydet"""
        try:
            self.log.info("Sistem bilgileri toplanmaya başlandı")
            
            veriler = {}
            for kod, toplayici in self.collectors.items():
                try:
                    self.log.info(f"{self._get_collector_name(kod)} bilgileri toplanıyor...")
                    veriler[kod] = toplayici.collect()
                    self.log.info(f"{self._get_collector_name(kod)} bilgileri başarıyla toplandı")
                except Exception as e:
                    self.log.error(f"{self._get_collector_name(kod)} bilgileri toplanırken hata: {str(e)}")
                    veriler[kod] = {"hata_mesaji": str(e)}

            # Üst bilgileri ekle
            veriler["sistem_bilgisi"] = {
                "bilgisayar_adi": socket.gethostname(),
                "tarih_saat": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "program_versiyonu": "1.0.0"
            }

            self._save(veriler)
            self.log.info("Tüm sistem bilgileri başarıyla toplandı ve kaydedildi")
            return veriler
            
        except Exception as e:
            self.log.error(f"Kritik sistem hatası: {str(e)}")
            raise

    def _save(self, data):
        """JSON olarak kaydet"""
        try:
            # Dosya adı oluştur
            pc_adi = socket.gethostname()
            tarih = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            dosya = f"Sistem_Raporu_{pc_adi}_{tarih}.json"
            
            yol = self.out_dir / dosya
            
            # Türkçe karakter desteği ile kaydet
            with open(yol, 'w', encoding='utf-8') as fp:
                json.dump(data, fp, ensure_ascii=False, indent=2, sort_keys=True)
                
            self.log.info(f"Rapor başarıyla kaydedildi: {yol}")
            
        except Exception as e:
            self.log.error(f"Rapor kaydetme hatası: {e}")
            raise

    def _get_collector_name(self, code):
        """Toplayıcı kodlarını tam isimlere çevir"""
        names = {
            'donanim': 'Donanım',
            'yazilim': 'Yazılım', 
            'ag': 'Ağ',
            'guvenlik': 'Güvenlik'
        }
        return names.get(code, code)