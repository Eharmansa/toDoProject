import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys
import os
import logging
from datetime import datetime

from agent import Agent
from utils.log import setup_logger

class App:
    def __init__(self):
        # Ana pencere
        self.w = tk.Tk()
        self.w.title("Sistem Bilgi Toplayıcı")
        self.w.geometry("500x350")
        self.w.resizable(False, False)
        
        # Çıktı dizini
        exe_dir = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path.cwd()
        self.out_dir = exe_dir / "output"
        self.out_dir.mkdir(exist_ok=True)
        
        self._init_ui()
        self._center_window()

    def _init_ui(self):
        # Stil
        s = ttk.Style()
        s.configure('TButton', padding=5)
        s.configure('H.TLabel', font=('Arial', 14, 'bold'))
        s.configure('I.TLabel', font=('Arial', 10))
        
        # Ana frame
        f = ttk.Frame(self.w, padding=10)
        f.pack(fill=tk.BOTH, expand=True)
        
        # Başlık
        ttk.Label(f, text="Sistem Bilgi Toplayıcı", style='H.TLabel').pack(pady=10)
        
        # Bilgi
        info = """
• Donanım (CPU, RAM, Disk)
• Yazılım (OS, Programlar) 
• Ağ (IP, MAC)
• Güvenlik (AV, Firewall)

Bilgiler JSON formatında kaydedilir."""
        ttk.Label(f, text=info, style='I.TLabel', justify=tk.LEFT).pack(pady=10)
        
        # Butonlar
        bf = ttk.Frame(f)
        bf.pack(pady=20)
        
        self.run_btn = ttk.Button(
            bf, text="Bilgileri Topla",
            command=self._collect,
            style='TButton'
        )
        self.run_btn.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            bf, text="Çıktı Klasörü",
            command=lambda: os.startfile(self.out_dir),
            style='TButton'
        ).pack(side=tk.LEFT, padx=5)
        
        # Progress
        self.prog = ttk.Progressbar(f, length=400, mode='determinate')
        self.prog.pack(pady=10)
        
        self.status = ttk.Label(f, text="", style='I.TLabel')
        self.status.pack()

    def _collect(self):
        try:
            # UI kilitle
            self.run_btn.state(['disabled'])
            self.prog['value'] = 0
            self.status['text'] = "Bilgiler toplanıyor..."
            self.w.update()
            
            # Logger
            setup_logger()
            log = logging.getLogger(__name__)
            
            # Agent
            a = Agent()
            
            # İlerleme
            for i, step in enumerate(['hw', 'sw', 'net', 'sec']):
                self.status['text'] = f"{step.upper()} bilgileri toplanıyor..."
                self.prog['value'] = (i + 0.5) * 25
                self.w.update()
                
            # Topla
            a.collect()
            
            # Tamamlandı
            self.prog['value'] = 100
            self.status['text'] = "Tamamlandı!"
            messagebox.showinfo("Başarılı", f"Bilgiler toplandı!\nKonum: {self.out_dir}")
            
        except Exception as e:
            messagebox.showerror("Hata", str(e))
            log.error(f"Hata: {e}")
            
        finally:
            self.run_btn.state(['!disabled'])
            self.w.update()

    def _center_window(self):
        self.w.update_idletasks()
        w = self.w.winfo_width()
        h = self.w.winfo_height()
        x = (self.w.winfo_screenwidth() // 2) - (w // 2)
        y = (self.w.winfo_screenheight() // 2) - (h // 2)
        self.w.geometry(f'{w}x{h}+{x}+{y}')

    def run(self):
        self.w.mainloop()

if __name__ == "__main__":
    App().run()