import psutil
import socket
import logging
import wmi
import subprocess

class NetCollector:
    def __init__(self):
        self.log = logging.getLogger(__name__)
        self.wmi = wmi.WMI()

    def collect(self):
        """Ağ bilgilerini topla"""
        try:
            return {
                "host": socket.gethostname(),
                "ifs": self._get_ifs(),
                "conns": self._get_conns(),
                "dns": self._get_dns(),
                "routes": self._get_routes(),
                "stats": self._get_stats()
            }
        except Exception as e:
            self.log.error(f"Ağ hatası: {e}")
            raise

    def _get_ifs(self):
        """Ağ arayüzleri"""
        try:
            ifs = []
            for nic in self.wmi.Win32_NetworkAdapter(PhysicalAdapter=True):
                try:
                    iface = {
                        "name": nic.Name,
                        "type": nic.AdapterType,
                        "mac": nic.MACAddress,
                        "speed": f"{int(nic.Speed)/1000000:.0f}Mbps" if nic.Speed else None,
                        "status": "Up" if nic.NetEnabled else "Down"
                    }
                    
                    # IP config
                    for cfg in self.wmi.Win32_NetworkAdapterConfiguration(MACAddress=nic.MACAddress):
                        if cfg.IPEnabled:
                            iface.update({
                                "ips": cfg.IPAddress,
                                "masks": cfg.IPSubnet,
                                "gw": cfg.DefaultIPGateway,
                                "dhcp": cfg.DHCPEnabled
                            })
                    ifs.append(iface)
                except: continue
            return ifs
        except Exception as e:
            self.log.error(f"Arayüz hatası: {e}")
            return []

    def _get_conns(self):
        """Aktif bağlantılar"""
        try:
            conns = []
            for c in psutil.net_connections(kind='inet'):
                try:
                    conn = {
                        "local": f"{c.laddr.ip}:{c.laddr.port}",
                        "remote": f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else None,
                        "status": c.status,
                        "type": "TCP" if c.type == socket.SOCK_STREAM else "UDP",
                        "pid": c.pid
                    }
                    try:
                        p = psutil.Process(c.pid)
                        conn["proc"] = p.name()
                    except:
                        conn["proc"] = "?"
                    conns.append(conn)
                except: continue
            return sorted(conns, key=lambda x: x['status'])
        except Exception as e:
            self.log.error(f"Bağlantı hatası: {e}")
            return []

    def _get_dns(self):
        """DNS sunucuları"""
        try:
            dns = set()
            for nic in self.wmi.Win32_NetworkAdapterConfiguration(IPEnabled=True):
                if nic.DNSServerSearchOrder:
                    dns.update(nic.DNSServerSearchOrder)
            return list(dns)
        except Exception as e:
            self.log.error(f"DNS hatası: {e}")
            return []

    def _get_routes(self):
        """Routing tablosu"""
        try:
            routes = []
            out = subprocess.check_output("route print", shell=True, text=True)
            parse = False
            
            for line in out.split('\n'):
                if "Network Destination" in line:
                    parse = True
                    continue
                if parse and line.strip():
                    try:
                        parts = line.split()
                        if len(parts) >= 4:
                            routes.append({
                                "dst": parts[0],
                                "mask": parts[1],
                                "gw": parts[2],
                                "if": parts[3]
                            })
                    except: continue
            return routes
        except Exception as e:
            self.log.error(f"Route hatası: {e}")
            return []

    def _get_stats(self):
        """Ağ istatistikleri"""
        try:
            stats = {}
            for name, s in psutil.net_io_counters(pernic=True).items():
                stats[name] = {
                    "sent": f"{s.bytes_sent / (1024*1024):.1f}MB",
                    "recv": f"{s.bytes_recv / (1024*1024):.1f}MB",
                    "p_sent": s.packets_sent,
                    "p_recv": s.packets_recv,
                    "errs": s.errin + s.errout,
                    "drops": s.dropin + s.dropout
                }
            return stats
        except Exception as e:
            self.log.error(f"İstatistik hatası: {e}")
            return {} 