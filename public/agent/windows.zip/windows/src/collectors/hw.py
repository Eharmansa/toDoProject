import psutil
import wmi
import logging

class HWCollector:
    def __init__(self):
        self.log = logging.getLogger(__name__)
        self.wmi = wmi.WMI()

    def collect(self):
        """Donanım bilgilerini topla"""
        try:
            return {
                "cpu": self._get_cpu(),
                "ram": self._get_ram(),
                "disk": self._get_disk(),
                "gpu": self._get_gpu(),
                "mb": self._get_mb()
            }
        except Exception as e:
            self.log.error(f"Donanım hatası: {e}")
            raise

    def _get_cpu(self):
        """CPU bilgileri"""
        try:
            freq = psutil.cpu_freq()
            cpu = {
                "cores": {
                    "physical": psutil.cpu_count(logical=False),
                    "logical": psutil.cpu_count()
                },
                "freq": {
                    "max": f"{freq.max:.0f} MHz" if freq else None,
                    "current": f"{freq.current:.0f} MHz" if freq else None
                },
                "usage": {
                    "per_cpu": [f"{x:.1f}%" for x in psutil.cpu_percent(percpu=True)],
                    "total": f"{psutil.cpu_percent():.1f}%"
                }
            }
            
            # WMI detayları
            for c in self.wmi.Win32_Processor():
                cpu.update({
                    "name": c.Name.strip(),
                    "manufacturer": c.Manufacturer,
                    "arch": c.Architecture,
                    "id": c.ProcessorId
                })
                break
                
            return cpu
        except Exception as e:
            self.log.error(f"CPU hatası: {e}")
            return {}

    def _get_ram(self):
        """RAM bilgileri"""
        try:
            vm = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            ram = {
                "total": f"{vm.total / (1024**3):.1f}GB",
                "used": f"{vm.used / (1024**3):.1f}GB",
                "free": f"{vm.available / (1024**3):.1f}GB",
                "percent": f"{vm.percent}%",
                "swap": {
                    "total": f"{swap.total / (1024**3):.1f}GB",
                    "used": f"{swap.used / (1024**3):.1f}GB",
                    "free": f"{swap.free / (1024**3):.1f}GB"
                }
            }
            
            # Fiziksel RAM modülleri
            modules = []
            for m in self.wmi.Win32_PhysicalMemory():
                modules.append({
                    "size": f"{float(m.Capacity) / (1024**3):.1f}GB",
                    "speed": f"{m.Speed}MHz" if m.Speed else None,
                    "manufacturer": m.Manufacturer,
                    "location": m.DeviceLocator
                })
            ram["modules"] = modules
            
            return ram
        except Exception as e:
            self.log.error(f"RAM hatası: {e}")
            return {}

    def _get_disk(self):
        """Disk bilgileri"""
        try:
            disks = {
                "physical": [],
                "partitions": []
            }
            
            # Fiziksel diskler
            for d in self.wmi.Win32_DiskDrive():
                disks["physical"].append({
                    "name": d.Caption,
                    "size": f"{float(d.Size) / (1024**3):.1f}GB",
                    "interface": d.InterfaceType,
                    "model": d.Model
                })
            
            # Bölümler
            for p in psutil.disk_partitions():
                try:
                    u = psutil.disk_usage(p.mountpoint)
                    disks["partitions"].append({
                        "device": p.device,
                        "mount": p.mountpoint,
                        "fs": p.fstype,
                        "total": f"{u.total / (1024**3):.1f}GB",
                        "used": f"{u.used / (1024**3):.1f}GB",
                        "free": f"{u.free / (1024**3):.1f}GB",
                        "percent": f"{u.percent}%"
                    })
                except:
                    continue
                    
            return disks
        except Exception as e:
            self.log.error(f"Disk hatası: {e}")
            return {}

    def _get_gpu(self):
        """GPU bilgileri"""
        try:
            gpus = []
            for g in self.wmi.Win32_VideoController():
                gpus.append({
                    "name": g.Name,
                    "ram": f"{float(g.AdapterRAM if g.AdapterRAM else 0) / (1024**3):.1f}GB",
                    "driver": g.DriverVersion,
                    "res": f"{g.CurrentHorizontalResolution}x{g.CurrentVerticalResolution}" if g.CurrentHorizontalResolution else None
                })
            return gpus
        except Exception as e:
            self.log.error(f"GPU hatası: {e}")
            return []

    def _get_mb(self):
        """Anakart bilgileri"""
        try:
            for b in self.wmi.Win32_BaseBoard():
                return {
                    "manufacturer": b.Manufacturer,
                    "product": b.Product,
                    "version": b.Version
                }
            return {}
        except Exception as e:
            self.log.error(f"Anakart hatası: {e}")
            return {} 