import wmi
import winreg
import logging
import subprocess
import win32com.client
import pythoncom

class SecCollector:
    def __init__(self):
        self.log = logging.getLogger(__name__)
        # WMI bağlantısını daha güvenli şekilde kur
        try:
            self.wmi = wmi.WMI()
        except:
            self.wmi = None

    def collect(self):
        """Güvenlik bilgilerini topla"""
        try:
            bilgiler = {}
            
            # Her metodu ayrı ayrı dene
            metodlar = {
                "antivirusler": self._get_av,
                "guvenlik_duvari": self._get_fw,
                "windows_defender": self._get_defender,
                "kullanici_hesap_kontrolu": self._get_uac,
                "guncellemeler": self._get_updates,
                "disk_sifreleme": self._get_bitlocker
            }
            
            for ad, metod in metodlar.items():
                try:
                    bilgiler[ad] = metod()
                except Exception as e:
                    self.log.error(f"{ad} bilgileri alınamadı: {e}")
                    bilgiler[ad] = {"durum": "alınamadı", "hata": str(e)}
            
            return bilgiler
            
        except Exception as e:
            self.log.error(f"Güvenlik bilgileri toplanırken hata: {e}")
            return {"durum": "başarısız", "hata": str(e)}

    def _get_av(self):
        """Antivirüs durumu - Farklı Windows sürümleri için"""
        avs = []
        
        try:
            # Windows 10/11 için Security Center
            key_path = r"SOFTWARE\Microsoft\Security Center\Provider\Antivirus"
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, 
                    winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
                    i = 0
                    while True:
                        try:
                            name = winreg.EnumKey(key, i)
                            with winreg.OpenKey(key, name) as av_key:
                                avs.append({
                                    "isim": winreg.QueryValueEx(av_key, "DisplayName")[0],
                                    "durum": "Aktif" if winreg.QueryValueEx(av_key, "State")[0] == 1 else "Pasif",
                                    "kaynak": "Security Center"
                                })
                            i += 1
                        except WindowsError:
                            break
            except:
                pass

            # Eski Windows sürümleri için WMI
            if not avs and self.wmi:
                for product in self.wmi.Win32_Product():
                    if "antivirus" in product.Name.lower():
                        avs.append({
                            "isim": product.Name,
                            "durum": "Yüklü",
                            "versiyon": product.Version,
                            "kaynak": "WMI"
                        })

            return avs or [{"durum": "Antivirüs bulunamadı"}]
            
        except Exception as e:
            self.log.error(f"Antivirüs bilgileri alınamadı: {e}")
            return [{"durum": "hata", "mesaj": str(e)}]

    def _get_fw(self):
        """Güvenlik duvarı - Tüm Windows sürümleri için"""
        try:
            # Önce netsh komutu dene
            try:
                out = subprocess.check_output(
                    "netsh advfirewall show allprofiles", 
                    shell=True, text=True, 
                    stderr=subprocess.DEVNULL
                )
                
                profiller = {}
                current = None
                
                for line in out.split('\n'):
                    line = line.strip()
                    if "Profile Settings:" in line:
                        current = line.split(':')[0].lower()
                        profiller[current] = {}
                    elif current and "State" in line:
                        profiller[current]["durum"] = "Açık" if "ON" in line.upper() else "Kapalı"
                
                return {
                    "profiller": profiller,
                    "kaynak": "netsh"
                }
                
            except:
                # Netsh çalışmazsa Registry'den kontrol et
                key_path = r"SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy"
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, 
                    winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
                    
                    return {
                        "durum": "Açık" if winreg.QueryValueEx(key, "EnableFirewall")[0] == 1 else "Kapalı",
                        "kaynak": "Registry"
                    }
                    
        except Exception as e:
            self.log.error(f"Güvenlik duvarı bilgileri alınamadı: {e}")
            return {"durum": "alınamadı", "hata": str(e)}

    def _get_defender(self):
        """Windows Defender"""
        try:
            # PowerShell ile Defender durumunu al
            cmd = "powershell Get-MpComputerStatus | ConvertTo-Json"
            out = subprocess.check_output(cmd, shell=True, text=True)
            
            import json
            status = json.loads(out)
            
            return {
                "enabled": status.get("AntivirusEnabled", False),
                "realtime": status.get("RealTimeProtectionEnabled", False),
                "signature": status.get("AntivirusSignatureVersion", "Unknown")
            }
            
        except Exception as e:
            self.log.error(f"Defender hatası: {e}")
            return {}

    def _get_uac(self):
        """UAC ayarları"""
        try:
            # Registry yolu düzelt
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY
            )
            
            uac = {
                "enabled": False,
                "level": "Unknown"
            }
            
            try:
                uac["enabled"] = bool(winreg.QueryValueEx(key, "EnableLUA")[0])
                level = winreg.QueryValueEx(key, "ConsentPromptBehaviorAdmin")[0]
                uac["level"] = {0:"None", 1:"Basic", 2:"Secure"}.get(level, "Unknown")
            except:
                pass
                
            winreg.CloseKey(key)
            return uac
            
        except Exception as e:
            self.log.error(f"UAC hatası: {e}")
            return {}

    def _get_updates(self):
        """Windows güncellemeleri"""
        try:
            upds = []
            for u in self.wmi.Win32_QuickFixEngineering():
                upds.append({
                    "id": u.HotFixID,
                    "desc": u.Description,
                    "date": u.InstalledOn,
                    "by": u.InstalledBy
                })
            return sorted(upds, key=lambda x: x['date'] if x['date'] else '', reverse=True)
        except Exception as e:
            self.log.error(f"Update hatası: {e}")
            return []

    def _get_bitlocker(self):
        """BitLocker durumu"""
        try:
            bit = {}
            for d in self.wmi.Win32_EncryptableVolume():
                bit[d.DriveLetter] = {
                    "prot": d.ProtectionStatus,
                    "conv": d.ConversionStatus,
                    "enc": d.EncryptionMethod,
                    "on": bool(d.ProtectionStatus)
                }
            return bit
        except Exception as e:
            self.log.error(f"BitLocker hatası: {e}")
            return {} 