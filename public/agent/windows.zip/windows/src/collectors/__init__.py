from .hw import HWCollector as DonanımToplayici
from .sw import SWCollector as YazılımToplayici
from .net import NetCollector as AğToplayici
from .sec import SecCollector as GüvenlikToplayici

__all__ = ['DonanımToplayici', 'YazılımToplayici', 'AğToplayici', 'GüvenlikToplayici'] 