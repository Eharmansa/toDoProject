import winreg
import logging
import psutil
from datetime import datetime

class SWCollector:
    def __init__(self):
        self.log = logging.getLogger(__name__)

    def collect(self):
        """Yazılım bilgilerini topla"""
        try:
            return {
                "os": self._get_os(),
                "apps": self._get_apps(),
                "procs": self._get_procs(),
                "svcs": self._get_svcs(),
                "startup": self._get_startup()
            }
        except Exception as e:
            self.log.error(f"Yazılım hatası: {e}")
            raise

    def _get_os(self):
        """İşletim sistemi bilgileri"""
        try:
            import platform
            uname = platform.uname()
            return {
                "name": uname.system,
                "ver": uname.version,
                "rel": uname.release,
                "arch": platform.architecture()[0],
                "machine": uname.machine
            }
        except Exception as e:
            self.log.error(f"OS hatası: {e}")
            return {}

    def _get_apps(self):
        """Yüklü uygulamalar"""
        apps = []
        paths = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")
        ]
        
        for hkey, path in paths:
            try:
                key = winreg.OpenKey(hkey, path)
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        skey_name = winreg.EnumKey(key, i)
                        skey = winreg.OpenKey(key, skey_name)
                        try:
                            app = {
                                "name": winreg.QueryValueEx(skey, "DisplayName")[0],
                                "ver": winreg.QueryValueEx(skey, "DisplayVersion")[0],
                                "pub": winreg.QueryValueEx(skey, "Publisher")[0],
                                "date": winreg.QueryValueEx(skey, "InstallDate")[0]
                            }
                            apps.append(app)
                        except: pass
                        winreg.CloseKey(skey)
                    except: continue
                winreg.CloseKey(key)
            except Exception as e:
                self.log.error(f"Registry hatası: {e}")
                continue
        
        return sorted(apps, key=lambda x: x.get('name', '').lower())

    def _get_procs(self):
        """Çalışan işlemler"""
        try:
            procs = []
            for p in psutil.process_iter(['pid', 'name', 'username', 'memory_info', 'cpu_percent', 'create_time']):
                try:
                    info = p.info
                    procs.append({
                        "pid": info['pid'],
                        "name": info['name'],
                        "user": info['username'],
                        "mem": f"{info['memory_info'].rss / (1024*1024):.1f}MB",
                        "cpu": f"{info['cpu_percent']:.1f}%",
                        "start": datetime.fromtimestamp(info['create_time']).isoformat()
                    })
                except: continue
            return sorted(procs, key=lambda x: float(x['cpu'].rstrip('%')), reverse=True)
        except Exception as e:
            self.log.error(f"İşlem hatası: {e}")
            return []

    def _get_svcs(self):
        """Windows servisleri"""
        try:
            svcs = []
            for s in psutil.win_service_iter():
                try:
                    info = s.as_dict()
                    svcs.append({
                        "name": info['name'],
                        "disp": info['display_name'],
                        "status": info['status'],
                        "start": info['start_type'],
                        "user": info['username']
                    })
                except: continue
            return sorted(svcs, key=lambda x: x['name'])
        except Exception as e:
            self.log.error(f"Servis hatası: {e}")
            return []

    def _get_startup(self):
        """Başlangıç uygulamaları"""
        startup = []
        locs = [
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run")
        ]
        
        for hkey, path in locs:
            try:
                key = winreg.OpenKey(hkey, path)
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        name, value, _ = winreg.EnumValue(key, i)
                        startup.append({
                            "name": name,
                            "cmd": value,
                            "loc": path
                        })
                    except: continue
                winreg.CloseKey(key)
            except Exception as e:
                self.log.error(f"Başlangıç hatası: {e}")
                continue
                
        return sorted(startup, key=lambda x: x['name']) 