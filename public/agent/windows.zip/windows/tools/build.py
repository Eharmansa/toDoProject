import os
import sys
from pathlib import Path
import subprocess
import shutil
import time

def clean():
    """Temizlik yap"""
    files = ['build', 'dist', 'SysBilgi.spec']
    for f in files:
        try:
            if os.path.isfile(f):
                os.unlink(f)
            elif os.path.isdir(f):
                shutil.rmtree(f)
        except Exception as e:
            print(f"Uyarı: {f} silinemiyor: {e}")

def build():
    """Tek exe oluştur"""
    print("Build başladı...")
    
    root = Path(__file__).parent.parent
    os.chdir(root)
    
    # Önce temizlik
    clean()
    time.sleep(2)  # Biraz bekle
    
    # Dizinler
    for d in ['output', 'logs']:
        Path(d).mkdir(exist_ok=True)
    
    try:
        # PyInstaller
        subprocess.run([
            'pyinstaller',
            '--name=SysBilgi',
            '--onefile',
            '--noconsole',
            '--clean',
            '--uac-admin',
            '--hidden-import=wmi',
            '--hidden-import=win32com.client',
            '--hidden-import=win32com.client.gencache',
            '--hidden-import=pythoncom',
            '--hidden-import=pywintypes',
            '--hidden-import=psutil',
            'src/main.py'
        ], check=True)
        
        print("\nBuild tamamlandı!")
        print(f"Konum: {root/'dist'/'SysBilgi.exe'}")
        
    except Exception as e:
        print(f"\nHata: {e}")
        sys.exit(1)

if __name__ == "__main__":
    build() 